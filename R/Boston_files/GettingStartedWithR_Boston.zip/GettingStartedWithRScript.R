#Getting Started with R
#introduction to R scripts and basic concepts
#@MaryJoWebster
#June 2019

#Start with this file for this class,then move to the "GettingStartedWithRMarkdown" file at the end


#Steps you have already taken:
#Install R and RStudio
#Download this script: http://mjwebster.github.io/DataJ/R/SettingUpForRClasses.R
#Follow directions in that script 
#it should have installed packages, created directories and loaded some data for you


#here's the install packages code just in case
packages <- c("tidyverse", "stringr", "janitor", "rmarkdown", "lubridate", 
              "ggthemes", "knitr", "htmltools", "rprojroot", "kableExtra",
              "sf", "mapview", "leaflet", "tidycensus", "devtools", "readxl", "scales", "formattable", "DT")
if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(packages, rownames(installed.packages())), repos = "http://cran.us.r-project.org")  
}


#Open RStudio, go to File menu and choose "New Project". Choose "Existing Directory"
#navigate to the "R_GettingStarted" directory created by the script above
#Choose "open" and then "Create project"
#Then R will show you are in a project called "R_GettingStarted" (look in upper right corner of RStudio)
#and you will see the files in that directory (over in the Files section to the right)


# look around RStudio -----------------------------------------------------

#There are 4 panes. We are currently in the script editor area
#In the upper right, note the Environment tab. When we import data or create an new data frames they will appear there
#In the lower right, the Files tab shows us what is stored in our working directory
#The packages tab shows us which packages are loaded on our machine; if checked, it's turned on for this project
#Any ggplots we make will display under the Plots tab
#The help tab is useful for finding out information about a particular package or function
#The Console (below) will display a trail of each of our steps and show output from what we do in the script but it will not be saved
#Terminal is something you would use if you connect your project to Github

#Types of R files - scripts, notebooks, RMarkdown, etc

#About R Notebooks: https://rviews.rstudio.com/2017/03/15/why-i-love-r-notebooks/
#R Markdown is a file format for making dynamic documents with R. An R Markdown document is written 
#in markdown (an easy-to-write plain text format) and contains chunks of embedded R code,


# start here --------------------------------------------------------------


#This script will allow us to run code and save it. 
#But our results will not be displayed within the page
#They will be displayed in the Console area (below)
#Scripts are great for importing and cleaning data;
#less sufficient for analysis and making charts



# Load libraries ----------------------------------------------------------

#Now that the packages have installed, we'll start the code we need for this particular project
#You first need to load any of the packages (also referred to as libraries) that you will use for this script
#You do this every time you write R code (in scripts, RMarkdown, Notebooks, etc)
#for this script we're only going to use a compilation of packages called tidyverse

#to run code, highlight the line of code below and go to the Run button above
#choose "run selected lines"

library(tidyverse) 

#find out more information about tidyverse by highlighting and running this code
?tidyverse


#https://www.tidyverse.org/
#packages we will be using from within tidyverse: 
#readr --  importing text files 
#dplyr --  general analysis 
#gpplot2 --  making charts 
#tidyr -- data cleaning
#readxl -- importing Excel files


getwd()  #how to check what directory we are working from


#You can set a permanent default directory under Tools/Global Options. Will need to close and
#reopen R to make it work. In the future, when you make a new project, it will guess that 
#you want to save it in that directory


#We're going to work with the Social Security baby names file for Massachussets
#I got it from here: https://www.ssa.gov/OACT/babynames/limits.html

#Data contains the number of Social Security applications (a proxy for births) 
#by state & gender & name & year of birth
#Excludes names with less than 5 in a given year/state

#Record layout
#column 1 - state abbreviation
#column 2 - gender
#column 3 - year of birth 
#column 4 - name
#column 5 - number of births

#The most basic syntax for importing a csv file with readr package is this:
rawdata <-  read_csv('MA.TXT')


  
  
#Let's look at our data and see what it looks like
#click on the data frame in the Environment tab to open it
#the table will pop open as a new tab above
#we can see that it doesn't have column names


#We can add an optional argument telling it that there aren't column names
#this will overwrite the data frame we've already made
rawdata <-  read_csv('MA.TXT', col_names=FALSE)



#Is that better? View the data again


#R "guesses" the field types based on the 1st 1,000 rows
#Here it's guessing that the second column is a True or False and 
#it has switched all the "F" (female) values to "FALSE"
#And it eliminated the "M" (male) values altogether
#So we need to tell it to store that column as character

rawdata <-  read_csv("MA.TXT", col_names=FALSE,
                     col_types=cols(X2=col_character()))

#Let's now look at the structure of the data frame
#this shows us the format of each column and shows a sample of the data in each column
str(rawdata)


#Only remaining problem is that we don't want X1, X2, etc as our column names
#We'll use the rename() function to fix that

#Here's how we can find out which package the rename() function comes from
?rename()


#The beautiful thing about dplyr (from tidyverse) is that we can "string" operations together
#using a pipe (%>%). 
#Keyboard shortcut on Windows: Control-Shift M. 
#Keyboard shortcut on Mac: Command-Shift-M

#We'll add rename function on the end of our import process
#And this time we'll name our dataframe "babynames" by using the assignment operator (<-)
#keyboard shortcut on Windows ( Alt+- )
#Keyboard shortcut on Mac ( Option+- )

babynames <-  read_csv("MA.TXT", col_names=FALSE,
                     col_types=cols(X2="c"))%>% 
        rename(state=X1, gender=X2, yr= X3, name=X4, num_births=X5)



#remove the old data frame from our working environment
#this function is from Base R
rm(rawdata)

#let's look at the top of our data frame
#this function is from Base R
head(babynames)


#Let's look at some of the options for analysis that dplyr package (from Tidyverse) gives us

?dplyr

#Click on the first "useful link" to the dplyr webpage
#https://dplyr.tidyverse.org/

#Dplyr "verbs"
#select()
#filter()
#summarise() or summarize()
#arrange()
#group_by()
#mutate()

#If you've used SQL, this will look quite familiar but 
#the order of operations is a bit different


#To use dplyr, you first need to tell it what dataframe to use
#this query below is telling it to use the babynames dataframe and then to display just 4 of the columns
#it will return all the rows, though,because we didn't specify anything about that

babynames %>%  select(gender, yr, name, num_births)

#You can type the column names in whatever order you want
babynames %>% select(yr, gender, name, num_births)


#Let's limit it to only rows with certain values
#Let's say we only want the rows with the name "Mary"

babynames %>% filter(name=='Mary') %>% select(yr, name, num_births) 

#Notice that there are 2 equal signs
#Mary is surrounded by quotes because it is stored as character


#WRITE YOUR OWN query looking for your name (or a name you like)





#Make a new data frame
#Use the assignment operator (<-) to assign data from our existing data frame to a new one
#Let's just pull out the 2018 data

babynames2018 <-  babynames %>% filter(yr==2018)



#This has given you a taste of what you can do with R, but it doesn't work very well for displaying 
#results of our analysis. So let's move to an RMarkdown file
#Save and close this script.
#Clear your environment by clicking the button that looks like a broom

